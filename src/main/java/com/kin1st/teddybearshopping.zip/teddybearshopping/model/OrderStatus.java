package com.kin1st.teddybearshopping.model;

public enum OrderStatus {
    PENDING,
    PAID,
    SHIPPED,
    CANCELED
}
