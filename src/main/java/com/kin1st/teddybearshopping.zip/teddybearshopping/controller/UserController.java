package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.dto.ChangePasswordRequest;
import com.kin1st.teddybearshopping.model.User;
import com.kin1st.teddybearshopping.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ✅ Lấy thông tin người dùng hiện tại
    @GetMapping("/me")
    public ResponseEntity<?> getMyInfo(Authentication authentication) {
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Ẩn password trước khi trả về
        user.setPassword(null);
        return ResponseEntity.ok(user);
    }

    // ✅ Cập nhật thông tin cá nhân (ví dụ: email)
    @PutMapping("/me")
    public ResponseEntity<?> updateMyInfo(Authentication authentication, @RequestBody User updatedUser) {
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setEmail(updatedUser.getEmail());
        userRepository.save(user);
        return ResponseEntity.ok("Cập nhật thông tin thành công!");
    }

    // ✅ Đổi mật khẩu
    @PutMapping("/change-password")
    public ResponseEntity<?> changePassword(Authentication authentication,
                                            @RequestBody ChangePasswordRequest request) {
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Kiểm tra mật khẩu cũ
        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            return ResponseEntity.badRequest().body("Mật khẩu cũ không đúng!");
        }

        // Không cho phép dùng lại mật khẩu cũ
        if (passwordEncoder.matches(request.getNewPassword(), user.getPassword())) {
            return ResponseEntity.badRequest().body("Mật khẩu mới không được trùng mật khẩu cũ!");
        }

        // Cập nhật mật khẩu mới
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        return ResponseEntity.ok("✅ Đổi mật khẩu thành công!");
    }
}
