package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.model.Cart;
import com.kin1st.teddybearshopping.service.CartService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carts")
public class CartController {
    private final CartService cartService;
    public CartController(CartService cartService) { this.cartService = cartService; }

    @GetMapping
    public Cart getMyCart(Authentication authentication) {
        return cartService.getCartByUser(authentication.getName());
    }

    @PostMapping("/add")
    public Cart addToCart(Authentication authentication,
                          @RequestParam Long productId,
                          @RequestParam int quantity) {
        return cartService.addToCart(authentication.getName(), productId, quantity);
    }

    @DeleteMapping("/remove/{itemId}")
    public Cart removeItem(Authentication authentication, @PathVariable Long itemId) {
        return cartService.removeItem(authentication.getName(), itemId);
    }
}
