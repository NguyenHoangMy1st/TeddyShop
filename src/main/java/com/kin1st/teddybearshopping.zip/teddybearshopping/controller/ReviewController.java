package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.model.Review;
import com.kin1st.teddybearshopping.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reviews")
@Tag(name = "Review API", description = "APIs for managing product reviews")
@SecurityRequirement(name = "bearerAuth")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @Operation(summary = "Thêm đánh giá sản phẩm", 
              description = "Thêm đánh giá cho sản phẩm đã mua và đã giao hàng")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Đánh giá đã được tạo thành công",
                   content = @Content(schema = @Schema(implementation = Review.class))),
        @ApiResponse(responseCode = "400", description = "Dữ liệu không hợp lệ hoặc không tìm thấy sản phẩm/người dùng"),
        @ApiResponse(responseCode = "401", description = "Chưa xác thực"),
        @ApiResponse(responseCode = "403", description = "Không có quyền thực hiện thao tác")
    })
    @PostMapping
    public ResponseEntity<?> addReview(
            @Parameter(hidden = true) Authentication authentication,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                description = "Thông tin đánh giá",
                required = true,
                content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ReviewRequest.class)
                )
            )
            @RequestBody Map<String, Object> body) {
        try {
            String username = authentication.getName();
            Long productId = Long.valueOf(body.get("productId").toString());
            int rating = (int) body.get("rating");
            String comment = body.get("comment").toString();

            Review review = reviewService.addReview(username, productId, rating, comment);
            return ResponseEntity.status(201).body(review);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Lấy danh sách đánh giá theo sản phẩm",
              description = "Lấy tất cả đánh giá của một sản phẩm cụ thể")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Thành công"),
        @ApiResponse(responseCode = "404", description = "Không tìm thấy sản phẩm")
    })
    @GetMapping("/product/{productId}")
    public ResponseEntity<List<Review>> getReviews(
            @Parameter(description = "ID của sản phẩm", required = true, example = "1")
            @PathVariable Long productId) {
        return ResponseEntity.ok(reviewService.getReviewsByProduct(productId));
    }

    @Operation(summary = "Cập nhật đánh giá", 
              description = "Cập nhật nội dung đánh giá (chỉ chủ sở hữu mới được phép)")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cập nhật thành công",
                   content = @Content(schema = @Schema(implementation = Review.class))),
        @ApiResponse(responseCode = "400", description = "Dữ liệu không hợp lệ"),
        @ApiResponse(responseCode = "401", description = "Chưa xác thực"),
        @ApiResponse(responseCode = "403", description = "Không có quyền chỉnh sửa đánh giá này"),
        @ApiResponse(responseCode = "404", description = "Không tìm thấy đánh giá")
    })
    @PutMapping("/{id}")
    public ResponseEntity<?> updateReview(
            @Parameter(hidden = true) Authentication authentication,
            @Parameter(description = "ID của đánh giá cần cập nhật", required = true, example = "1")
            @PathVariable Long id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                description = "Thông tin cập nhật đánh giá",
                required = true,
                content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ReviewRequest.class)
                )
            )
            @RequestBody Map<String, Object> body) {
        try {
            String username = authentication.getName();
            int rating = (int) body.get("rating");
            String comment = body.get("comment").toString();

            Review updated = reviewService.updateReview(id, username, rating, comment);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Xóa đánh giá", 
              description = "Xóa đánh giá (chỉ chủ sở hữu hoặc admin mới được phép)")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Xóa thành công"),
        @ApiResponse(responseCode = "401", description = "Chưa xác thực"),
        @ApiResponse(responseCode = "403", description = "Không có quyền xóa đánh giá này"),
        @ApiResponse(responseCode = "404", description = "Không tìm thấy đánh giá")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteReview(
            @Parameter(hidden = true) Authentication authentication,
            @Parameter(description = "ID của đánh giá cần xóa", required = true, example = "1")
            @PathVariable Long id) {
        try {
            String username = authentication.getName();
            reviewService.deleteReview(id, username);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    /**
     * Lớp DTO cho request tạo/cập nhật đánh giá
     */
    @Schema(description = "Dữ liệu yêu cầu tạo/cập nhật đánh giá")
    public static class ReviewRequest {
        @Schema(description = "ID sản phẩm", example = "1", required = true)
        private Long productId;
        
        @Schema(description = "Điểm đánh giá (1-5 sao)", example = "5", minimum = "1", maximum = "5", required = true)
        private Integer rating;
        
        @Schema(description = "Nội dung đánh giá", example = "Sản phẩm rất tốt, giao hàng nhanh", required = true)
        private String comment;
        
        // Getters and Setters
        public Long getProductId() {
            return productId;
        }
        
        public void setProductId(Long productId) {
            this.productId = productId;
        }
        
        public Integer getRating() {
            return rating;
        }
        
        public void setRating(Integer rating) {
            this.rating = rating;
        }
        
        public String getComment() {
            return comment;
        }
        
        public void setComment(String comment) {
            this.comment = comment;
        }
    }
}
