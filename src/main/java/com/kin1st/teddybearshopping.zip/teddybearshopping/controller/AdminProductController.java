package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.model.Product;
import com.kin1st.teddybearshopping.service.AdminProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/products") // 👈 Rõ ràng cho admin
public class AdminProductController {

    private final AdminProductService adminProductService;

    public AdminProductController(AdminProductService adminProductService) {
        this.adminProductService = adminProductService;
    }

    // ✅ Lấy tất cả sản phẩm (không phân trang)
    @GetMapping
    public List<Product> getAllProducts() {
        return adminProductService.getAllProducts();
    }

    // ✅ Thêm sản phẩm
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return adminProductService.createProduct(product);
    }

    // ✅ Cập nhật sản phẩm
    @PutMapping("/{id}")
    public Optional<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        return adminProductService.updateProduct(id, product);
    }

    // ✅ Xóa sản phẩm
    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        adminProductService.deleteProduct(id);
    }
}
