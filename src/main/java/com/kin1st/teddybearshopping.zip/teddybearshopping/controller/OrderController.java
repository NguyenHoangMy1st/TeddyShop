package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.dto.CheckoutRequest;
import com.kin1st.teddybearshopping.model.Order;
import com.kin1st.teddybearshopping.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // ✅ Thanh toán đơn hàng
    @PostMapping("/checkout")
    public ResponseEntity<?> checkout(Authentication authentication,
                                      @RequestBody CheckoutRequest req) {
        try {
            Order order = orderService.checkoutSelectedItems(
                    authentication.getName(),
                    req.getSelectedItemIds(),
                    req.getCustomerName(),
                    req.getCustomerEmail(),
                    req.getCustomerAddress()
            );
            return ResponseEntity.status(201).body(order);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // ✅ Lấy danh sách đơn hàng của người dùng hiện tại
    @GetMapping("/my")
    public ResponseEntity<List<Order>> getMyOrders(Authentication authentication) {
        List<Order> orders = orderService.getMyOrders(authentication.getName());
        return ResponseEntity.ok(orders);
    }
}
