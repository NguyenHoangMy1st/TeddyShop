package com.kin1st.teddybearshopping.controller;

import com.kin1st.teddybearshopping.dto.PagedResponse;
import com.kin1st.teddybearshopping.model.Product;
import com.kin1st.teddybearshopping.service.ProductService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // Lấy danh sách sản phẩm có phân trang
    @GetMapping
    public PagedResponse<Product> getAllProducts(@RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "10") int size) {
        Page<Product> productPage = productService.getAllProducts(PageRequest.of(page, size));

        return new PagedResponse<>(
                productPage.getContent(),
                productPage.getNumber(),
                productPage.getTotalPages(),
                productPage.getTotalElements()
        );
    }

    // Xem chi tiết sản phẩm
    @GetMapping("/{id}")
    public Optional<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }
    // Tìm kiếm sản phẩm theo tên có phân trang
    @GetMapping("/search")
    public PagedResponse<Product> searchProducts(@RequestParam String name,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "10") int size) {
        Page<Product> productPage = productService.searchByName(name, PageRequest.of(page, size));
        return new PagedResponse<>(
                productPage.getContent(),
                productPage.getNumber(),
                productPage.getTotalPages(),
                productPage.getTotalElements()
        );
    }
}
