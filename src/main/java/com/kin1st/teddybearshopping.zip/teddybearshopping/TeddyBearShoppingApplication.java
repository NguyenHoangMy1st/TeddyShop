package com.kin1st.teddybearshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeddyBearShoppingApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeddyBearShoppingApplication.class, args);
    }

}
